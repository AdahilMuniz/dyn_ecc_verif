################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (12.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Drivers/flash/spif.c 

OBJS += \
./Drivers/flash/spif.o 

C_DEPS += \
./Drivers/flash/spif.d 


# Each subdirectory must supply rules for building sources it contributes
Drivers/flash/%.o Drivers/flash/%.su Drivers/flash/%.cyclo: ../Drivers/flash/%.c Drivers/flash/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32L4S5xx -c -I../Core/Inc -I../Drivers/STM32L4xx_HAL_Driver/Inc -I../Drivers/STM32L4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32L4xx/Include -I../Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Drivers-2f-flash

clean-Drivers-2f-flash:
	-$(RM) ./Drivers/flash/spif.cyclo ./Drivers/flash/spif.d ./Drivers/flash/spif.o ./Drivers/flash/spif.su

.PHONY: clean-Drivers-2f-flash

